const appSettings = {

    //auth
    default_token_refresh_time: 900 //seconds


}



export default appSettings