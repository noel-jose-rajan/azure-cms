export type Pagination = {
  page: number;
  total: number;
};
