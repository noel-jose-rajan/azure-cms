// import { Row } from "antd";
// import { CorrespondenceDetailType } from "../../types";
// import ElectronicAttachments from "./components/electronic-attachments";
// import PhysicalAttachments from "./components/physical-attachments";
// // import { useEffect, useState } from "react";
// // import { canAbleToAccessAttachmentHistory } from "../../service";

// interface CorrespondenceAttachmentsProps {
//   details?: CorrespondenceDetailType;
//   canViewHistory: boolean;
// }

// export default function CorrespondenceAttachments({
//   details,
//   canViewHistory,
// }: CorrespondenceAttachmentsProps) {
//   return (
//     <Row style={{ padding: 10 }}>
//       <ElectronicAttachments details={details} canView={canViewHistory} />
//       <PhysicalAttachments details={details} canView={canViewHistory} />
//     </Row>
//   );
// }
