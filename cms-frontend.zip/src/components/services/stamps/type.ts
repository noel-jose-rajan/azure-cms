export interface StampItemType {
  ID: number;
  IsGeneral: boolean;
  Description: string;
  EntityID: number;
  CreatedAt: string;
  CreatedBy: string;
}
