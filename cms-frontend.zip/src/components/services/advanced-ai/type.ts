export interface UploadResponseType {
  status: string;
  chunks_added: number;
  file_name: string;
  session_id: string;
}
