export interface ApproverUser {
  key: string;
  description: string;
}

export interface ApproverUserOugUnit {
  key: string;
  description: string;
}
