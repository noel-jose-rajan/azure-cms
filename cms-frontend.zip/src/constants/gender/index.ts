export enum GENDER {
  NEUTRAL = "NEUTRAL",
  MALE = "MALE",
  FEMALE = "FEMALE",
}
