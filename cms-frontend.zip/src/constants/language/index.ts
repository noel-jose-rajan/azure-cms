export enum LANGUAGE {
  ARABIC_KW = "ar-KW",
  ENGLISH_INT = "en-INT",
  ARABIC = "ar",
  ENGLISH_INTERNATIONAL = "en",
  ENGLISH_US = "en-US",
}
