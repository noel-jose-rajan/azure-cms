import ENV from "../env"

export const OT_API = ENV.OT_API
export const API_URL = ENV.API_URL