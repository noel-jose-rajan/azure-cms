export const calandarArr = [
  {
    id: 7,
    arLabel: "الأحد",
    enLabel: "Sun",
  },
  {
    id: 1,
    arLabel: "الأثنين",
    enLabel: "Mon",
  },
  {
    id: 2,
    arLabel: "الثلاثاء",
    enLabel: "Tues",
  },
  { id: 3, arLabel: "الأربعاء", enLabel: "Wed" },
  {
    id: 4,
    arLabel: "الخميس",
    enLabel: "Thu",
  },
  { id: 5, arLabel: "الجمعة", enLabel: "Fri" },
  {
    id: 6,
    arLabel: "السبت",
    enLabel: "Sat",
  },
];
