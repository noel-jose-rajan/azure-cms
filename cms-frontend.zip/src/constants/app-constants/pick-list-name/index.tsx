enum PICK_LIST_NAME {
    APPROVAL_SUBTYPE = "Approval subtype",
    CORRESPONDENCE_TYPE = "Correspondence Type",
    DOCUMENT_TYPE = "Document Type",
    ESCALATION_PERFORMER = "Escalation Performer",
    EXTERNAL_ENTITY_CLASSIFICATION = "External Entity Classification",
    HISTORY_STATUS = "History Status",
    INBOUND_SOURCE = "Inbound Source",
    LANGUAGE = "Language",
    ORG_UNIT_LEVEL = "Org Unit Level",
    OUTBOUND_SENDING_TYPE = "outbound sending type",
    OUTBOUND_TYPES = "outbound types",
    PHYSICAL_ATTACHMENT_TYPE = "Physical Attachment Type",
    REJECTION_REASON = "Rejection Reason",
    REQUIRED_ACTION = "Required Action",
    SECURITY_LEVEL = "Security Level",
    STAMP_OPTIONS = "Stamp Options",
    STATUS = "Status",
    TASK_SUBJECT = "Task Subject",
    URGENCY_LEVEL = "Urgency Level",
}



export default PICK_LIST_NAME