export const abbyConstants = {
  role: 1,
  station: 3,
  token: "Basic QWRtaW5pc3RyYXRvcjp4RUB2b3gqMjQ=",
  projectId: 1,
  batchId: 0,
};
